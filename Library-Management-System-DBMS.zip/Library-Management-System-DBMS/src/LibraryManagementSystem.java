import java.io.*;
import java.util.*;

public class LibraryManagementSystem {

    //Stored file names in variables
    public static final String USERS_FILE = "users.txt";
    public static final String BOOKS_FILE = "books.txt";
    public static final String BORROWED_BOOKS_FILE = "borrowed_books.txt";
    public static final String BOOK_REQUESTS_FILE = "book_requests.txt";



    //created arraylist objects global
    public static final Map<String, User> users = new HashMap<>();
    public static final List<Book> books = new ArrayList<>();
    public static final List<String> borrowedBooks = new ArrayList<>();

    public static final List<String> bookRequests = new ArrayList<>();


    //Starting Point of Program
    public static void main(String[] args) {

        //Loaded all data in arraylist Objects
        loadUsers();
        loadBooks();
        loadBorrowedBooks();
        loadBookRequests();

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nLibrary Management System");
            System.out.println("1. Login as Student");
            System.out.println("2. Login as Librarian");
            System.out.println("3. Login as Administrator");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            //Stored Updated work in back files
            if (choice == 4) {
                saveBooks();
                saveBorrowedBooks();
                saveUsers();
                saveBookRequests();
                System.out.println("Goodbye!");
                break;
            }

            System.out.print("Enter User ID: ");
            String id = scanner.nextLine();
            System.out.print("Enter Password: ");
            String password = scanner.nextLine();

            User user = users.get(id);
            if (user != null && user.getPassword().equals(password)) {
                System.out.println("Login successful!");
                user.displayMenu();
            } else {
                System.out.println("Invalid credentials. Please try again.");
            }
        }

        scanner.close();
    }


    //Function is reading from file line by line using filereader function and storing in users list
    private static void loadUsers() {
        try (BufferedReader reader = new BufferedReader(new FileReader(USERS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                User user = User.fromFileFormat(line);
                users.put(user.id, user);
            }
        } catch (IOException e) {
            System.out.println("Error loading users: " + e.getMessage());
        }
    }


    //Functions is saving updated users list in users.txt
    private static void saveUsers() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(USERS_FILE))) {
            for (User user : users.values()) {
                writer.write(user.toFileFormat());
                writer.newLine();
            }
            System.out.println("Users saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving users: " + e.getMessage());
        }
    }



    //Loading books from file and storing in book list
    private static void loadBooks() {
        try (BufferedReader reader = new BufferedReader(new FileReader(BOOKS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                books.add(Book.fromFileFormat(line));
            }
        } catch (IOException e) {
            System.out.println("Error loading books: " + e.getMessage());
        }
    }


    private static void loadBorrowedBooks() {
        try (BufferedReader reader = new BufferedReader(new FileReader(BORROWED_BOOKS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                borrowedBooks.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error loading borrowed books: " + e.getMessage());
        }
    }

    private static void saveBooks() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(BOOKS_FILE))) {
            for (Book book : books) {
                writer.write(book.toFileFormat());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving books: " + e.getMessage());
        }
    }

    private static void saveBorrowedBooks() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(BORROWED_BOOKS_FILE))) {
            for (String record : borrowedBooks) {
                writer.write(record);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving borrowed books: " + e.getMessage());
        }
    }

    private static void loadBookRequests() {
        try (BufferedReader reader = new BufferedReader(new FileReader(BOOK_REQUESTS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                bookRequests.add(line);
            }
            System.out.println("Book requests loaded successfully.");
        } catch (IOException e) {
            System.out.println("Error loading book requests: " + e.getMessage());
        }
    }

    private static void saveBookRequests() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(BOOK_REQUESTS_FILE))) {
            for (String request : bookRequests) {
                writer.write(request);
                writer.newLine();
            }
            System.out.println("Book requests saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving book requests: " + e.getMessage());
        }
    }


}
