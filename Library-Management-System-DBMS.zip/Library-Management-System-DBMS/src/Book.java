class Book {
    private String title;
    private String author;
    private String isbn;
    private String genre;
    private boolean available;

    public Book(String title, String author, String isbn, String genre) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.genre = genre;
        this.available = true;
    }


    // Setters
    public void setAuthor(String author) {
        this.author = author;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }
    public String getIsbn() {
        return isbn;
    }
    public String getAuthor() {
        return author;
    }

    public String getGenre() {
        return genre;
    }

   public String getTitle(){
        return title;
   }

    public boolean isAvailable() {
        return available;
    }

    public void borrow() {
        this.available = false;
    }

    public void returnBook() {
        this.available = true;
    }

    public String toFileFormat() {
        return title + "," + author + "," + isbn + "," + genre + "," + available;
    }

    public static Book fromFileFormat(String line) {
        String[] parts = line.split(",");
        Book book = new Book(parts[0], parts[1], parts[2], parts[3]);
        if (!Boolean.parseBoolean(parts[4])) {
            book.borrow();
        }
        return book;
    }

    @Override
    public String toString() {
        return "Title: " + title + ", Author: " + author + ", ISBN: " + isbn + ", Genre: " + genre + ", Available: " + available;
    }

}
