import java.util.*;

class Librarian extends User {
    public Librarian(String id, String name, String address, String email, String dateOfBirth, String password) {
        super(id, name, address, email, dateOfBirth, "Librarian", password);
    }

    @Override
    public void displayMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nLibrarian Menu:");
            System.out.println("1. View Borrower Details");
            System.out.println("2. Approve/Deny Book Requests");
            System.out.println("3. Manage Catalog");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    viewBorrowerDetails();
                    break;
                case 2:
                    processBookRequests(scanner);
                    break;
                case 3:
                    manageCatalog(scanner);
                    break;
                case 4:
                    System.out.println("Exiting Librarian Menu...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }


    private void processBookRequests(Scanner scanner) {
        if (LibraryManagementSystem.bookRequests.isEmpty()) {
            System.out.println("\nNo pending book requests.");
            return;
        }

        System.out.println("\nPending Book Requests:");
        for (int i = 0; i < LibraryManagementSystem.bookRequests.size(); i++) {
            String request = LibraryManagementSystem.bookRequests.get(i);
            String[] parts = request.split(",");
            System.out.println((i + 1) + ". Requested by: " + parts[0] + ", Title: " + parts[1] + ", Author: " + parts[2] + ", ISBN: " + parts[3] + ", Genre: " + parts[4]);
        }

        while (true) {
            System.out.print("\nEnter the request number to process (or 0 to exit): ");
            int requestNumber = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            if (requestNumber == 0) {
                System.out.println("Exiting book request processing.");
                break;
            }

            if (requestNumber < 1 || requestNumber > LibraryManagementSystem.bookRequests.size()) {
                System.out.println("Invalid request number. Try again.");
                continue;
            }

            String selectedRequest = LibraryManagementSystem.bookRequests.get(requestNumber - 1);
            String[] parts = selectedRequest.split(",");
            String studentId = parts[0];
            String title = parts[1];
            String author = parts[2];
            String isbn = parts[3];
            String genre = parts[4];

            System.out.println("Processing Request: " + title + " by " + author);
            System.out.print("Approve (A) or Deny (D): ");
            String action = scanner.nextLine().toUpperCase();

            if (action.equals("A")) {
                LibraryManagementSystem.books.add(new Book(title, author, isbn, genre)); // Add to books list
                LibraryManagementSystem.bookRequests.remove(selectedRequest); // Remove from requests list
                System.out.println("Book approved and added to the library.");
            } else if (action.equals("D")) {
                LibraryManagementSystem.bookRequests.remove(selectedRequest); // Remove from requests list
                System.out.println("Book request denied.");
            } else {
                System.out.println("Invalid action. Please enter A (Approve) or D (Deny).");
            }
        }
    }

    private void viewBorrowerDetails() {
        System.out.println("\nBorrower Details:");
        for (String record : LibraryManagementSystem.borrowedBooks) {
            String[] parts = record.split(",");
            String userId = parts[0];
            String bookTitle = parts[1];
            String borrowDate = parts[2];

            User user = LibraryManagementSystem.users.get(userId);
            if (user != null && user instanceof Student) {
                System.out.println("Borrower: " + user.name + ", Book: " + bookTitle + ", Borrowed On: " + borrowDate);
            }
        }
    }

    private void approveOrDenyRequests(Scanner scanner) {
        System.out.println("\nApprove/Deny Borrow Requests:");
        System.out.println("Note: This feature is not fully implemented since no request-tracking system exists yet.");
        System.out.println("Imagine this is where you approve/deny pending borrow requests.");
    }

    private void manageCatalog(Scanner scanner) {
        while (true) {
            System.out.println("\nCatalog Management:");
            System.out.println("1. Add a Book");
            System.out.println("2. Remove a Book");
            System.out.println("3. Update Book Details");
            System.out.println("4. Exit Catalog Management");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addBook(scanner);
                    break;
                case 2:
                    removeBook(scanner);
                    break;
                case 3:
                    updateBook(scanner);
                    break;
                case 4:
                    System.out.println("Exiting Catalog Management...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void addBook(Scanner scanner) {
        System.out.println("\nEnter Book Details:");
        System.out.print("Title: ");
        String title = scanner.nextLine();
        System.out.print("Author: ");
        String author = scanner.nextLine();
        System.out.print("ISBN: ");
        String isbn = scanner.nextLine();
        System.out.print("Genre: ");
        String genre = scanner.nextLine();

        LibraryManagementSystem.books.add(new Book(title, author, isbn, genre));
        System.out.println("Book added to the catalog successfully!");
    }

    private void removeBook(Scanner scanner) {
        System.out.println("\nEnter the Title of the Book to Remove:");
        String title = scanner.nextLine();

        for (Book book : LibraryManagementSystem.books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                LibraryManagementSystem.books.remove(book);
                System.out.println("Book removed from the catalog successfully!");
                return;
            }
        }
        System.out.println("Book not found in the catalog.");
    }

    private void updateBook(Scanner scanner) {
        System.out.println("\nEnter the Title of the Book to Update:");
        String title = scanner.nextLine();

        for (Book book : LibraryManagementSystem.books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                System.out.print("Enter new Author (leave blank to keep current): ");
                String newAuthor = scanner.nextLine();
                System.out.print("Enter new ISBN (leave blank to keep current): ");
                String newIsbn = scanner.nextLine();
                System.out.print("Enter new Genre (leave blank to keep current): ");
                String newGenre = scanner.nextLine();


                if (!newAuthor.isEmpty()) book.setAuthor(newAuthor);
                if (!newIsbn.isEmpty()) book.setIsbn(newIsbn);
                if (!newGenre.isEmpty()) book.setGenre(newGenre);

                System.out.println("Book details updated successfully!");
                return;
            }
        }
        System.out.println("Book not found in the catalog.");
    }

}
