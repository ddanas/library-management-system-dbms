import java.util.*;

class Student extends User {
    public Student(String id, String name, String address, String email, String dateOfBirth, String password) {
        super(id, name, address, email, dateOfBirth, "Student", password);
    }

    @Override
    public void displayMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nStudent Menu:");
            System.out.println("1. View Available Books");
            System.out.println("2. Borrow a Book");
            System.out.println("3. Return a Book");
            System.out.println("4. View Borrowed Books");
            System.out.println("5. Update Personal Information");
            System.out.println("6. createNewBookRequest");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    viewAvailableBooks();
                    break;
                case 2:
                    borrowBook(scanner);
                    break;
                case 3:
                    returnBook(scanner);
                    break;
                case 4:
                    viewBorrowedBooks();
                    break;
                case 5:
                    updatePersonalInformation(scanner);
                    break;
                case 6:
                    createNewBookRequest(scanner);
                    break;
                case 7:
                    System.out.println("Exiting Student Menu...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void viewAvailableBooks() {
        System.out.println("\nAvailable Books:");
        for (Book book : LibraryManagementSystem.books) {
            if (book.isAvailable()) {
                System.out.println(book);
            }
        }
    }

    private void borrowBook(Scanner scanner) {
        System.out.println("\nEnter the title of the book you want to borrow:");
        String title = scanner.nextLine();

        for (Book book : LibraryManagementSystem.books) {
            if (book.getTitle().equalsIgnoreCase(title) && book.isAvailable()) {
                book.borrow();
                LibraryManagementSystem.borrowedBooks.add(id + "," + title + "," + new Date());
                System.out.println("Book borrowed successfully!");
                return;
            }
        }
        System.out.println("Book is not available or does not exist.");
    }

    private void returnBook(Scanner scanner) {
        System.out.println("\nEnter the title of the book you want to return:");
        String title = scanner.nextLine();

        for (String record : LibraryManagementSystem.borrowedBooks) {
            String[] parts = record.split(",");
            if (parts[0].equals(id) && parts[1].equalsIgnoreCase(title)) {
                LibraryManagementSystem.borrowedBooks.remove(record);

                for (Book book : LibraryManagementSystem.books) {
                    if (book.getTitle().equalsIgnoreCase(title)) {
                        book.returnBook();
                        System.out.println("Book returned successfully!");
                        return;
                    }
                }
            }
        }
        System.out.println("You have not borrowed this book.");
    }

    private void viewBorrowedBooks() {
        System.out.println("\nYour Borrowed Books:");
        for (String record : LibraryManagementSystem.borrowedBooks) {
            String[] parts = record.split(",");
            if (parts[0].equals(id)) {
                System.out.println("Book: " + parts[1] + ", Borrowed On: " + parts[2]);
            }
        }
    }

    private void updatePersonalInformation(Scanner scanner) {
        System.out.println("\nUpdate Personal Information:");

        System.out.print("Enter new Name (leave blank to keep current): ");
        String newName = scanner.nextLine();
        if (!newName.isEmpty()) {
            this.name = newName;
        }

        System.out.print("Enter new Address (leave blank to keep current): ");
        String newAddress = scanner.nextLine();
        if (!newAddress.isEmpty()) {
            this.address = newAddress;
        }

        System.out.print("Enter new Email (leave blank to keep current): ");
        String newEmail = scanner.nextLine();
        if (!newEmail.isEmpty()) {
            this.email = newEmail;
        }

        System.out.print("Enter new Date of Birth (YYYY-MM-DD) (leave blank to keep current): ");
        String newDateOfBirth = scanner.nextLine();
        if (!newDateOfBirth.isEmpty()) {
            this.dateOfBirth = newDateOfBirth;
        }

        System.out.print("Enter new Password (leave blank to keep current): ");
        String newPassword = scanner.nextLine();
        if (!newPassword.isEmpty()) {
            this.password = newPassword;
        }

        // Update the users map with the modified user
        LibraryManagementSystem.users.put(this.id, this);

        System.out.println("Personal information updated successfully!");
    }

    private void createNewBookRequest(Scanner scanner) {
        System.out.println("\nRequest a New Book:");

        System.out.print("Enter the Title of the Book: ");
        String title = scanner.nextLine();

        System.out.print("Enter the Author of the Book: ");
        String author = scanner.nextLine();

        System.out.print("Enter the ISBN of the Book: ");
        String isbn = scanner.nextLine();

        System.out.print("Enter the Genre of the Book: ");
        String genre = scanner.nextLine();

        // Add the request details
        String request = id + "," + title + "," + author + "," + isbn + "," + genre;
        LibraryManagementSystem.bookRequests.add(request); // Add to the global bookRequests list

        System.out.println("Your request for the new book has been submitted successfully!");
    }

}
