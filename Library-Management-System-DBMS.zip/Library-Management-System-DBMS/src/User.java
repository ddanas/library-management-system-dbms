import java.io.*;
import java.util.*;


//created abstract user class this is representing a generic user in Whole Project
abstract class User {

    // Attributes common to all user types
    protected String id;
    protected String name;
    protected String address;
    protected String email;
    protected String dateOfBirth;
    protected String role;
    protected String password;


    //Constructor to initialize a User object.
    public User(String id, String name, String address, String email, String dateOfBirth, String role, String password) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.role = role;
        this.password = password;
    }

    //setter and gatter functions
    public String getPassword() {
        return password;
    }

    public String getRole() {
        return role;
    }


    // Converts the User object to a formatted string for saving to a file.
    public String toFileFormat() {
        return id + "," + name + "," + address + "," + email + "," + dateOfBirth + "," + role + "," + password;
    }



    //This function determines the appropriate subclass (Student, Librarian, Administrator) based on roles
    public static User fromFileFormat(String line) {
        String[] parts = line.split(",");
        // Determine the user role and create the appropriate subclass instance
        if (parts[5].equalsIgnoreCase("Student")) {
            return new Student(parts[0], parts[1], parts[2], parts[3], parts[4], parts[6]);
        } else if (parts[5].equalsIgnoreCase("Librarian")) {
            return new Librarian(parts[0], parts[1], parts[2], parts[3], parts[4], parts[6]);
        } else if (parts[5].equalsIgnoreCase("Administrator")) {
            return new Administrator(parts[0], parts[1], parts[2], parts[3], parts[4], parts[6]);
        } else {
            //if no role found throw Exception
            throw new IllegalArgumentException("Unknown role: " + parts[5]);
        }
    }

    public abstract void displayMenu();
}
