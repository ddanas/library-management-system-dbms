import java.util.*;


//Administrator class extending the abstract User class

class Administrator extends User {
    public Administrator(String id, String name, String address, String email, String dateOfBirth, String password) {
        super(id, name, address, email, dateOfBirth, "Administrator", password);
    }

    @Override
    public void displayMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nAdministrator Menu:");
            System.out.println("1. Manage User Accounts");
            System.out.println("2. View Library Statistics");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    manageUserAccounts(scanner);
                    break;
                case 2:
                    viewLibraryStatistics();
                    break;
                case 3:
                    System.out.println("Exiting Administrator Menu...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void manageUserAccounts(Scanner scanner) {
        while (true) {
            System.out.println("\nManage User Accounts:");
            System.out.println("1. Add a User");
            System.out.println("2. Remove a User");
            System.out.println("3. View All Users");
            System.out.println("4. View Librarian Accounts");
            System.out.println("5. View Student Accounts");
            System.out.println("6. Exit User Management");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addUser(scanner);
                    break;
                case 2:
                    removeUser(scanner);
                    break;
                case 3:
                    viewAllUsers();
                    break;
                case 4:
                    viewLibrarianAccounts();
                    break;
                case 5:
                    viewStudentAccounts();
                    break;
                case 6:
                    System.out.println("Exiting User Management...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void addUser(Scanner scanner) {
        System.out.println("\nEnter New User Details:");
        System.out.print("ID: ");
        String id = scanner.nextLine();
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Address: ");
        String address = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Date of Birth (YYYY-MM-DD): ");
        String dateOfBirth = scanner.nextLine();
        System.out.print("Role (Student/Librarian/Administrator): ");
        String role = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();

        if (role.equalsIgnoreCase("Administrator")) {
            System.out.println("Cannot add new Administrator accounts.");
            return;
        }

        User newUser;
        switch (role.toLowerCase()) {
            case "student":
                newUser = new Student(id, name, address, email, dateOfBirth, password);
                break;
            case "librarian":
                newUser = new Librarian(id, name, address, email, dateOfBirth, password);
                break;
            default:
                System.out.println("Invalid role. User not added.");
                return;
        }

        LibraryManagementSystem.users.put(id, newUser);
        System.out.println("User added successfully!");
    }

    private void removeUser(Scanner scanner) {
        System.out.print("\nEnter the ID of the User to Remove: ");
        String id = scanner.nextLine();

        if (!LibraryManagementSystem.users.containsKey(id)) {
            System.out.println("User not found.");
            return;
        }

        User user = LibraryManagementSystem.users.get(id);
        if (user.getRole().equalsIgnoreCase("Administrator")) {
            System.out.println("Cannot remove Administrator accounts.");
            return;
        }

        LibraryManagementSystem.users.remove(id);
        System.out.println("User removed successfully!");
    }

    private void viewAllUsers() {
        System.out.println("\nAll Users:");
        for (User user : LibraryManagementSystem.users.values()) {
            System.out.println("ID: " + user.id + ", Name: " + user.name + ", Role: " + user.role);
        }
    }

    private void viewLibrarianAccounts() {
        System.out.println("\nLibrarian Accounts:");
        for (User user : LibraryManagementSystem.users.values()) {
            if (user.getRole().equalsIgnoreCase("Librarian")) {
                System.out.println("ID: " + user.id + ", Name: " + user.name + ", Email: " + user.email);
            }
        }
    }

    private void viewStudentAccounts() {
        System.out.println("\nStudent Accounts:");
        for (User user : LibraryManagementSystem.users.values()) {
            if (user.getRole().equalsIgnoreCase("Student")) {
                System.out.println("ID: " + user.id + ", Name: " + user.name + ", Email: " + user.email);
            }
        }
    }

    private void viewLibraryStatistics() {
        System.out.println("\nLibrary Statistics:");
        System.out.println("Total Books: " + LibraryManagementSystem.books.size());
        System.out.println("Borrowed Books: " + LibraryManagementSystem.borrowedBooks.size());
        System.out.println("Total Users: " + LibraryManagementSystem.users.size());
    }
}
