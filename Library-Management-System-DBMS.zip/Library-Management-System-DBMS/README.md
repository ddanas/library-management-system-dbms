# Library Management System

**Course:** Database Management Systems (DBMS)  
**Language:** Java  
**Project type:** Console-based academic project

## Overview
A Java library management application with separate menus for students, librarians, and administrators. It supports book browsing and borrowing, returns, book requests, catalog management, user account management, and basic library statistics.

## Features
- Role-based menus for students, librarians, and administrators
- Book catalog and availability tracking
- Borrowing, returning, and book requests
- Librarian catalog and request management
- Administrator user management and library statistics
- File-based persistence using text files

## Project structure
- `src/` — Java source files
- `users.txt` — fictional demo accounts
- `books.txt` — fictional demo book catalog
- `borrowed_books.txt` — demo borrowing record
- `book_requests.txt` — saved book requests

## Run locally
Requires a Java JDK. From the project root, compile the source files:

```bash
javac src/*.java
```

Then run:

```bash
java -cp src LibraryManagementSystem
```

The application reads and writes the text data files in the project root. Run it from that directory.

## Demo login accounts
These are fictional demonstration accounts, not real credentials:

| Role | User ID | Password |
|---|---|---|
| Student | `S001` | `student123` |
| Librarian | `L001` | `library123` |
| Administrator | `A001` | `admin123` |

**Security note:** This academic implementation stores passwords as plain text in `users.txt`. Do not use real or reused passwords. A production system should hash passwords and use a database with appropriate access controls.

## Current limitation
Despite being developed for a DBMS course, this version persists data in text files rather than connecting to a database engine such as MySQL or Oracle.
